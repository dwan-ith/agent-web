"""Serve the native knowledge site over operator-provided TLS."""

from __future__ import annotations

import argparse
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519
import uvicorn

from .app import create_app


def main() -> None:
    parser = argparse.ArgumentParser(description="Run an agent-only Agent Web site")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8843)
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--database", default=".agent-web/native-knowledge.db")
    parser.add_argument("--signing-key", required=True)
    parser.add_argument("--tls-certificate", required=True)
    parser.add_argument("--tls-private-key", required=True)
    args = parser.parse_args()
    key = serialization.load_pem_private_key(Path(args.signing_key).read_bytes(), password=None)
    if not isinstance(key, ed25519.Ed25519PrivateKey):
        parser.error("--signing-key must contain an Ed25519 private key")
    Path(args.database).parent.mkdir(parents=True, exist_ok=True)
    uvicorn.run(
        create_app(database=args.database, base_url=args.base_url, private_key=key),
        host=args.host,
        port=args.port,
        ssl_certfile=args.tls_certificate,
        ssl_keyfile=args.tls_private_key,
    )


if __name__ == "__main__":
    main()
