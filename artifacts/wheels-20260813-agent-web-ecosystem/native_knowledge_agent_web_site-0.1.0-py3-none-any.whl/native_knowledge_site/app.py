"""Agent-only publisher: JSON resources, discovery, links, actions, and proofs."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping
from urllib.parse import quote, urlencode, urlsplit

import base58
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import JSONResponse
from libagentweb import (
    AGENT_WEB_VERSION,
    DISCOVERY_MEDIA_TYPE,
    RESOURCE_MEDIA_TYPE,
    build_discovery_document,
    empty_affordances,
    http_action,
    sign_resource,
)

from .store import KnowledgeStore


DEFAULT_TOPICS = (
    {
        "slug": "agent-web",
        "title": "Agent Web",
        "summary": "A machine-native Web of linked resources and services.",
        "body": "Agents publish, discover, verify, navigate, and act without requiring an HTML projection.",
    },
    {
        "slug": "typed-links",
        "title": "Typed links",
        "summary": "Relations make unfamiliar resources navigable.",
        "body": "Agent browsers follow declared relations under explicit trust, origin, and traversal policy.",
    },
)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def create_app(
    *,
    database: str | Path = ":memory:",
    base_url: str = "https://native.example",
    private_key: ed25519.Ed25519PrivateKey | None = None,
    seed_topics: Iterable[Mapping[str, str]] = DEFAULT_TOPICS,
) -> FastAPI:
    """Create a native Agent Web publisher with deliberately no HTML routes."""

    base_url = base_url.rstrip("/")
    parsed = urlsplit(base_url)
    if parsed.scheme != "https" or not parsed.netloc or parsed.path or parsed.query or parsed.fragment:
        raise ValueError("base_url must be an absolute HTTPS origin")
    key = private_key or ed25519.Ed25519PrivateKey.generate()
    publisher = f"{base_url}/.well-known/agent-web"
    method = f"{publisher}#key-1"
    public = key.public_key().public_bytes(
        serialization.Encoding.Raw,
        serialization.PublicFormat.Raw,
    )
    store = KnowledgeStore(database)
    store.seed(seed_topics)
    discovery = build_discovery_document(
        base_url=base_url,
        entry_point=f"{base_url}/resources/index",
        publisher=publisher,
        verification_methods=[
            {
                "id": method,
                "type": "Multikey",
                "controller": publisher,
                "publicKeyMultibase": "z" + base58.b58encode(b"\xed\x01" + public).decode("ascii"),
            }
        ],
        assertion_methods=[method],
        name="Native Knowledge",
        description="An agent-only knowledge site with no World Wide Web projection.",
    )

    app = FastAPI(title="Native Knowledge Agent Web Site", docs_url=None, redoc_url=None)

    def signed(document: dict[str, Any]) -> dict[str, Any]:
        return sign_resource(
            document,
            private_key=key,
            publisher=publisher,
            verification_method=method,
        )

    def resource_base(
        *, resource_id: str, resource_type: list[str], kind: str, name: str,
        description: str, links: list[dict[str, Any]], data: Any,
        affordances: dict[str, Any] | None = None, updated_at: str | None = None,
    ) -> dict[str, Any]:
        timestamp = updated_at or _now()
        return signed({
            "@context": "urn:agent-web:context:0.2",
            "@id": resource_id,
            "@type": resource_type,
            "agentWeb": {"version": AGENT_WEB_VERSION, "kind": kind},
            "name": name,
            "description": description,
            "links": links,
            "affordances": affordances or empty_affordances(),
            "provenance": {
                "publisher": publisher,
                "createdAt": timestamp,
                "updatedAt": timestamp,
                "canonical": resource_id,
            },
            "data": data,
        })

    def collection_resource() -> dict[str, Any]:
        resource_id = f"{base_url}/resources/index"
        topics = store.topics()
        affordances = empty_affordances()
        affordances["actions"]["search"] = http_action(
            description="Search this native Agent Web site.",
            url=f"{base_url}/resources/search",
            method="GET",
            input_schema={
                "type": "object",
                "required": ["q"],
                "additionalProperties": False,
                "properties": {
                    "q": {"type": "string", "minLength": 1, "maxLength": 200},
                    "limit": {
                        "type": "integer",
                        "minimum": 1,
                        "maximum": 100,
                        "default": 20,
                    },
                },
            },
            output_schema={"$ref": "urn:agent-web:schema:resource:0.2"},
            safe=True,
            idempotent=True,
            authorization_level="normal",
        )
        links = [{"rel": "self", "href": resource_id, "mediaType": RESOURCE_MEDIA_TYPE}]
        links.extend({
            "rel": "item",
            "href": f"{base_url}/resources/topics/{quote(topic['slug'], safe='')}",
            "mediaType": RESOURCE_MEDIA_TYPE,
            "title": topic["title"],
        } for topic in topics)
        return resource_base(
            resource_id=resource_id,
            resource_type=["AgentWebCollection", "KnowledgeIndex"],
            kind="collection",
            name="Native Knowledge",
            description="Knowledge published directly on Agent Web for agent browsers.",
            links=links,
            affordances=affordances,
            data={"topicCount": len(topics), "humanView": None, "anpRequired": False},
        )

    @app.middleware("http")
    async def secure_machine_surface(request: Request, call_next: Any) -> Any:
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'none'"
        response.headers["Referrer-Policy"] = "no-referrer"
        return response

    @app.get("/.well-known/agent-web")
    async def discover() -> JSONResponse:
        return JSONResponse(discovery, media_type=DISCOVERY_MEDIA_TYPE)

    @app.get("/agent-web/0.2")
    async def profile() -> JSONResponse:
        return JSONResponse({
            "name": "Agent Web Resource Profile",
            "version": AGENT_WEB_VERSION,
            "resourceMediaType": RESOURCE_MEDIA_TYPE,
        })

    @app.get("/resources/index")
    async def index() -> JSONResponse:
        return JSONResponse(collection_resource(), media_type=RESOURCE_MEDIA_TYPE)

    @app.get("/resources/topics/{slug}")
    async def topic(slug: str) -> JSONResponse:
        record = store.topic(slug)
        if record is None:
            raise HTTPException(404, "topic not found")
        resource_id = f"{base_url}/resources/topics/{quote(slug, safe='')}"
        return JSONResponse(resource_base(
            resource_id=resource_id,
            resource_type=["AgentWebResource", "KnowledgeTopic"],
            kind="resource",
            name=record["title"],
            description=record["summary"],
            links=[
                {"rel": "self", "href": resource_id, "mediaType": RESOURCE_MEDIA_TYPE},
                {"rel": "collection", "href": f"{base_url}/resources/index", "mediaType": RESOURCE_MEDIA_TYPE},
            ],
            data={"body": record["body"]},
            updated_at=record["updated_at"],
        ), media_type=RESOURCE_MEDIA_TYPE)

    @app.get("/resources/search")
    async def search(q: str = Query(min_length=1, max_length=200), limit: int = Query(20, ge=1, le=100)) -> JSONResponse:
        records = store.search(q, limit=limit)
        resource_id = f"{base_url}/resources/search?{urlencode({'q': q, 'limit': limit})}"
        links = [
            {"rel": "self", "href": resource_id, "mediaType": RESOURCE_MEDIA_TYPE},
            {"rel": "collection", "href": f"{base_url}/resources/index", "mediaType": RESOURCE_MEDIA_TYPE},
        ]
        links.extend({
            "rel": "item",
            "href": f"{base_url}/resources/topics/{quote(record['slug'], safe='')}",
            "mediaType": RESOURCE_MEDIA_TYPE,
            "title": record["title"],
        } for record in records)
        return JSONResponse(resource_base(
            resource_id=resource_id,
            resource_type=["AgentWebCollection", "SearchResults"],
            kind="collection",
            name=f"Native Knowledge search: {q}",
            description="Agent-native search results.",
            links=links,
            data={"query": q, "count": len(records)},
        ), media_type=RESOURCE_MEDIA_TYPE)

    @app.get("/health")
    async def health() -> dict[str, Any]:
        return {"status": "ok", "publisher": publisher, "database": store.integrity_check()}

    @app.get("/ready")
    async def ready() -> JSONResponse:
        healthy = store.integrity_check()
        return JSONResponse(
            {"status": "ready" if healthy else "not-ready", "database": healthy},
            status_code=200 if healthy else 503,
        )

    app.state.knowledge_store = store
    app.state.publisher = publisher
    app.state.close = store.close
    return app
