from __future__ import annotations

import argparse
from pathlib import Path
from urllib.parse import urlsplit

from agent_web_server import PublisherIdentity
import uvicorn

from .app import create_app


def main() -> None:
    parser = argparse.ArgumentParser(description="Run secure Moltbook on Agent Web")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8443)
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--database", default=".agent-web/moltbook.db")
    parser.add_argument("--nonce-database", default=".agent-web/moltbook-nonces.db")
    parser.add_argument(
        "--authorization-database",
        default=".agent-web/moltbook-authorization.db",
    )
    parser.add_argument("--handle-database", default=".agent-web/moltbook-wns.db")
    parser.add_argument("--identity-directory")
    parser.add_argument("--did-document")
    parser.add_argument("--private-key")
    parser.add_argument("--tls-certificate", required=True)
    parser.add_argument("--tls-private-key", required=True)
    parser.add_argument("--forecast-entrypoint")
    args = parser.parse_args()
    parsed = urlsplit(args.base_url)
    if parsed.scheme != "https":
        parser.error("--base-url must use https")
    if parsed.port not in {None, args.port}:
        parser.error("--base-url port must match --port")
    for value in (
        args.database,
        args.nonce_database,
        args.authorization_database,
        args.handle_database,
    ):
        Path(value).parent.mkdir(parents=True, exist_ok=True)
    if args.identity_directory:
        if args.did_document or args.private_key:
            parser.error(
                "--identity-directory cannot be combined with direct identity files"
            )
        identity = PublisherIdentity.from_lifecycle(args.identity_directory)
    else:
        if not args.did_document or not args.private_key:
            parser.error(
                "provide --identity-directory or both identity file arguments"
            )
        identity = PublisherIdentity.from_files(
            args.did_document,
            args.private_key,
        )
    uvicorn.run(
        create_app(
            database=args.database,
            nonce_database=args.nonce_database,
            authorization_database=args.authorization_database,
            handle_database=args.handle_database,
            base_url=args.base_url,
            identity=identity,
            forecast_entrypoint=args.forecast_entrypoint,
        ),
        host=args.host,
        port=args.port,
        ssl_certfile=args.tls_certificate,
        ssl_keyfile=args.tls_private_key,
    )


if __name__ == "__main__":
    main()
