"""Command-line backup, verification, and restore operations."""

from __future__ import annotations

import argparse
import json
from typing import Any

from .operations import (
    create_backup_bundle,
    restore_backup_bundle,
    verify_backup_bundle,
)


def _database(value: str) -> tuple[str, str]:
    name, separator, path = value.partition("=")
    if not separator or not name or not path:
        raise argparse.ArgumentTypeError("database must use NAME=PATH")
    return name, path


def main() -> None:
    parser = argparse.ArgumentParser(description="Agent Web SQLite recovery tools")
    commands = parser.add_subparsers(dest="command", required=True)
    backup = commands.add_parser("backup")
    backup.add_argument("--database", action="append", type=_database, required=True)
    backup.add_argument("--destination", required=True)
    verify = commands.add_parser("verify")
    verify.add_argument("--bundle", required=True)
    restore = commands.add_parser("restore")
    restore.add_argument("--bundle", required=True)
    restore.add_argument("--destination", required=True)
    args = parser.parse_args()

    if args.command == "backup":
        databases = dict(args.database)
        if len(databases) != len(args.database):
            parser.error("database names must be unique")
        result: Any = create_backup_bundle(databases, args.destination)
    elif args.command == "verify":
        result = verify_backup_bundle(args.bundle)
    else:
        result = {
            name: str(path)
            for name, path in restore_backup_bundle(
                args.bundle,
                args.destination,
            ).items()
        }
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
