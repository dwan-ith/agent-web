"""Verified online backup and restore operations for SQLite operator state."""

from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
from typing import Any, Mapping
from uuid import uuid4


BACKUP_MANIFEST_SCHEMA = "agent-web-sqlite-backup/1"
_NAME = re.compile(r"^[a-z][a-z0-9_-]{0,62}$")


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def create_backup_bundle(
    databases: Mapping[str, str | Path],
    destination: str | Path,
) -> dict[str, Any]:
    """Create verified online SQLite snapshots without overwriting a bundle."""

    if not databases:
        raise ValueError("at least one SQLite database is required")
    destination_path = Path(destination).resolve()
    if destination_path.exists():
        raise FileExistsError(f"refusing to overwrite backup: {destination_path}")
    destination_path.parent.mkdir(parents=True, exist_ok=True)
    staging = destination_path.with_name(
        f".{destination_path.name}.{uuid4().hex}.staging"
    )
    staging.mkdir()
    records: dict[str, dict[str, Any]] = {}
    try:
        seen: set[Path] = set()
        for name, raw_source in sorted(databases.items()):
            if not _NAME.fullmatch(name):
                raise ValueError(f"invalid database name: {name!r}")
            source = Path(raw_source).resolve(strict=True)
            if source in seen:
                raise ValueError("the same SQLite database was supplied more than once")
            seen.add(source)
            if not source.is_file():
                raise ValueError(f"SQLite source is not a file: {source}")
            snapshot_name = f"{name}.sqlite3"
            snapshot = staging / snapshot_name
            _online_backup(source, snapshot)
            metadata = inspect_sqlite(snapshot)
            records[name] = {
                "sourceName": source.name,
                "backupFile": snapshot_name,
                "sha256": _sha256_file(snapshot),
                "bytes": snapshot.stat().st_size,
                "userVersion": metadata["userVersion"],
                "pageCount": metadata["pageCount"],
            }
        manifest = {
            "schema": BACKUP_MANIFEST_SCHEMA,
            "createdAt": _utc_now(),
            "databases": records,
        }
        _exclusive_write_json(staging / "manifest.json", manifest)
        verify_backup_bundle(staging)
        os.replace(staging, destination_path)
        return manifest
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        raise


def verify_backup_bundle(bundle: str | Path) -> dict[str, Any]:
    """Verify manifest containment, digests, and SQLite integrity."""

    root = Path(bundle).resolve(strict=True)
    manifest_path = root / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(manifest, dict) or manifest.get("schema") != (
        BACKUP_MANIFEST_SCHEMA
    ):
        raise ValueError("unsupported backup manifest")
    databases = manifest.get("databases")
    if not isinstance(databases, dict) or not databases:
        raise ValueError("backup manifest contains no databases")
    expected_files = {"manifest.json"}
    for name, record in databases.items():
        if not isinstance(name, str) or not _NAME.fullmatch(name):
            raise ValueError("backup manifest contains an invalid database name")
        if not isinstance(record, dict):
            raise ValueError("backup manifest database record must be an object")
        filename = record.get("backupFile")
        if not isinstance(filename, str) or Path(filename).name != filename:
            raise ValueError("backup database filename is unsafe")
        expected_files.add(filename)
        snapshot = (root / filename).resolve(strict=True)
        if not snapshot.is_relative_to(root) or not snapshot.is_file():
            raise ValueError("backup database escapes its bundle")
        if _sha256_file(snapshot) != record.get("sha256"):
            raise ValueError(f"backup digest mismatch: {name}")
        if snapshot.stat().st_size != record.get("bytes"):
            raise ValueError(f"backup size mismatch: {name}")
        metadata = inspect_sqlite(snapshot)
        if metadata["userVersion"] != record.get("userVersion"):
            raise ValueError(f"backup schema version mismatch: {name}")
    actual_files = {
        path.name for path in root.iterdir() if path.is_file()
    }
    if actual_files != expected_files:
        raise ValueError("backup bundle contains untracked or missing files")
    return manifest


def restore_backup_bundle(
    bundle: str | Path,
    destination: str | Path,
) -> dict[str, Path]:
    """Restore a verified bundle into a new directory, never over existing data."""

    manifest = verify_backup_bundle(bundle)
    bundle_path = Path(bundle).resolve(strict=True)
    destination_path = Path(destination).resolve()
    if destination_path.exists():
        raise FileExistsError(f"refusing to overwrite restore target: {destination_path}")
    destination_path.parent.mkdir(parents=True, exist_ok=True)
    staging = destination_path.with_name(
        f".{destination_path.name}.{uuid4().hex}.staging"
    )
    staging.mkdir()
    restored: dict[str, Path] = {}
    try:
        for name, record in manifest["databases"].items():
            source = bundle_path / record["backupFile"]
            target = staging / record["backupFile"]
            shutil.copyfile(source, target)
            _fsync_file(target)
            if _sha256_file(target) != record["sha256"]:
                raise ValueError(f"restored database digest mismatch: {name}")
            inspect_sqlite(target)
            restored[name] = destination_path / target.name
        _exclusive_write_json(staging / "manifest.json", manifest)
        _fsync_directory(staging)
        os.replace(staging, destination_path)
        return restored
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        raise


def inspect_sqlite(database: str | Path) -> dict[str, int]:
    """Fail unless a SQLite file passes quick and full integrity checks."""

    path = Path(database).resolve(strict=True)
    uri = f"{path.as_uri()}?mode=ro&immutable=1"
    connection = sqlite3.connect(uri, uri=True)
    try:
        quick = connection.execute("PRAGMA quick_check").fetchall()
        full = connection.execute("PRAGMA integrity_check").fetchall()
        if quick != [("ok",)] or full != [("ok",)]:
            raise ValueError(f"SQLite integrity check failed: {path}")
        return {
            "userVersion": int(connection.execute("PRAGMA user_version").fetchone()[0]),
            "pageCount": int(connection.execute("PRAGMA page_count").fetchone()[0]),
        }
    except sqlite3.DatabaseError as exc:
        raise ValueError(f"invalid SQLite database: {path}") from exc
    finally:
        connection.close()


def _online_backup(source: Path, destination: Path) -> None:
    source_connection = sqlite3.connect(f"{source.as_uri()}?mode=ro", uri=True)
    destination_connection = sqlite3.connect(destination)
    try:
        source_connection.backup(destination_connection)
        destination_connection.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        destination_connection.commit()
    finally:
        destination_connection.close()
        source_connection.close()
    _fsync_file(destination)


def _sha256_file(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _exclusive_write_json(path: Path, value: Mapping[str, Any]) -> None:
    content = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode("utf-8")
    descriptor = os.open(
        path,
        os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0),
        0o600,
    )
    with os.fdopen(descriptor, "wb") as stream:
        stream.write(content)
        stream.flush()
        os.fsync(stream.fileno())


def _fsync_file(path: Path) -> None:
    with path.open("r+b") as stream:
        os.fsync(stream.fileno())


def _fsync_directory(path: Path) -> None:
    if os.name == "nt":
        return
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
