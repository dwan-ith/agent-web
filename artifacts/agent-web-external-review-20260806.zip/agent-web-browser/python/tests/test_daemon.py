from __future__ import annotations

from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock, patch

from agent_web_browser import create_app
from agent_web_server import generate_publisher_identity, write_identity
from fastapi.testclient import TestClient


class BrowserDaemonTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = TemporaryDirectory()
        self.identity = generate_publisher_identity(
            base_url="https://localhost:7443",
            agent_name="browser",
            agent_description_path="/browser/ad.json",
        )
        self.did_path, self.key_path = write_identity(
            self.identity,
            directory=Path(self.temp.name) / "identity",
        )
        self.app = create_app(
            identity=self.identity,
            did_document_path=self.did_path,
            private_key_path=self.key_path,
            base_url="https://localhost:7443",
            static_directory=(
                Path(__file__).resolve().parents[1]
                / "src"
                / "agent_web_browser"
                / "static"
            ),
            allow_private_networks=True,
        )
        self.client = TestClient(
            self.app,
            base_url="https://localhost:7443",
        )

    def tearDown(self) -> None:
        self.client.close()
        self.temp.cleanup()

    def test_serves_real_ui_and_reports_browser_identity(self) -> None:
        page = self.client.get("/")
        self.assertEqual(page.status_code, 200)
        self.assertIn("Agent Web Browser", page.text)
        status = self.client.get("/api/status").json()
        self.assertEqual(status["callerDid"], self.identity.did)
        self.assertEqual(status["allowedOrigins"], [])

    def test_cross_origin_mutation_and_non_https_discovery_are_blocked(self) -> None:
        cross_origin = self.client.post(
            "/api/connect",
            headers={"Origin": "https://evil.test"},
            json={"agentDescriptionUrl": "https://agent.test/ad.json"},
        )
        self.assertEqual(cross_origin.status_code, 403)
        invalid = self.client.post(
            "/api/connect",
            json={"agentDescriptionUrl": "http://agent.test/ad.json"},
        )
        self.assertEqual(invalid.status_code, 400)

    def test_origin_policy_rejects_paths_and_accepts_https_origin(self) -> None:
        disconnected = self.client.post(
            "/api/origins",
            json={"origin": "https://agent.test"},
        )
        self.assertEqual(disconnected.status_code, 400)

    def test_connect_accepts_a_verified_wns_handle(self) -> None:
        candidate = SimpleNamespace(
            agent_description_url="https://publisher.example/moltbook/ad.json",
            handle_binding=SimpleNamespace(
                handle="moltbook.publisher.example",
                binding_generation="9",
            ),
            allowed_origins={"https://publisher.example"},
            discover_async=AsyncMock(
                return_value={
                    "name": "Moltbook",
                    "description": "Agent-native discussions",
                }
            ),
            open_entrypoint_async=AsyncMock(
                return_value={"@id": "https://publisher.example/resources/index.json"}
            ),
        )
        with patch(
            "agent_web_browser.daemon.AgentBrowser.from_handle_async",
            new=AsyncMock(return_value=candidate),
        ) as resolver:
            result = __import__("asyncio").run(
                self.app.state.browser_daemon.connect(
                    "moltbook.publisher.example"
                )
            )
        resolver.assert_awaited_once()
        connected = result["status"]["connectedAgent"]
        self.assertEqual(connected["url"], candidate.agent_description_url)
        self.assertEqual(connected["handle"], "moltbook.publisher.example")
        self.assertEqual(connected["bindingGeneration"], "9")


if __name__ == "__main__":
    unittest.main()
