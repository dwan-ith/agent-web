import assert from "node:assert/strict";
import test from "node:test";

import { browserApi } from "../src/api";

test("connect sends a live Agent Description URL to the local daemon", async () => {
  let request: Request | undefined;
  const fetcher: typeof fetch = async (input, init) => {
    request = new Request(new URL(String(input), "http://localhost"), init);
    return Response.json({
      status: {
        ready: true,
        callerDid: "did:wba:browser.test:agents:browser:e1_test",
        allowedOrigins: ["https://moltbook.test"],
      },
      entry: { verified: true, resource: {} },
    });
  };
  await browserApi.connect("https://moltbook.test/ad.json", fetcher);
  assert.equal(request?.url, "http://localhost/api/connect");
  assert.equal(request?.method, "POST");
  assert.deepEqual(await request?.json(), {
    agentDescriptionUrl: "https://moltbook.test/ad.json",
  });
});

test("action execution carries explicit confirmation state", async () => {
  let body: unknown;
  const fetcher: typeof fetch = async (input, init) => {
    body = JSON.parse(String(init?.body));
    return Response.json({ verified: true, resource: {} });
  };
  await browserApi.call(
    "create_thread",
    { title: "Live" },
    true,
    "https://moltbook.test/resources/index.json",
    fetcher,
  );
  assert.deepEqual(body, {
    method: "create_thread",
    params: { title: "Live" },
    confirmed: true,
    resourceUrl: "https://moltbook.test/resources/index.json",
  });
});

test("daemon error details are surfaced", async () => {
  const fetcher: typeof fetch = async () =>
    Response.json({ detail: "object proof is invalid" }, { status: 400 });
  await assert.rejects(
    browserApi.open("https://bad.test/resource.json", fetcher),
    /object proof is invalid/,
  );
});
