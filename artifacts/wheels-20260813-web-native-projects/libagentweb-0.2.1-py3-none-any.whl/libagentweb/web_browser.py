"""A Web-native Agent Browser with no ANP runtime dependency."""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Awaitable, Callable, Mapping
from urllib.parse import urlsplit

from .discovery import validate_discovery_document
from .identity import ResourceTrustError, verify_resource
from .network import request_json
from .resource import RESOURCE_MEDIA_TYPE, validate_resource


DocumentFetcher = Callable[[str], Awaitable[Mapping[str, Any]]]


class WebAgentBrowser:
    """Discover and navigate signed Agent Web resources over HTTPS alone."""

    def __init__(
        self,
        discovery_url: str,
        *,
        timeout: float = 8.0,
        max_response_bytes: int = 2 * 1024 * 1024,
        allowed_origins: set[str] | None = None,
        allow_private_networks: bool = False,
        fetch_document: DocumentFetcher | None = None,
    ) -> None:
        self.discovery_url = discovery_url
        self.timeout = timeout
        self.max_response_bytes = max_response_bytes
        self.allow_private_networks = allow_private_networks
        self.allowed_origins = {_origin(discovery_url)} | set(allowed_origins or ())
        self._fetch_document = fetch_document
        self._discovery: dict[str, Any] | None = None

    async def discover(self) -> dict[str, Any]:
        document = await self._get_json(self.discovery_url, discovery=True)
        self._discovery = validate_discovery_document(
            document,
            discovery_url=self.discovery_url,
        )
        return deepcopy(self._discovery)

    async def open_entrypoint(self) -> dict[str, Any]:
        discovery = self._discovery or await self.discover()
        return await self.open(str(discovery["agentWeb"]["entryPoint"]))

    async def open(self, resource_url: str) -> dict[str, Any]:
        discovery = self._discovery or await self.discover()
        document = validate_resource(await self._get_json(resource_url))
        if document["@id"] != resource_url:
            raise ResourceTrustError("resource @id does not match its transport URL")
        if document["provenance"]["publisher"] != discovery["publisher"]:
            raise ResourceTrustError("resource publisher differs from Web discovery")
        return verify_resource(
            document,
            controller_document=discovery,
            reject_expired=True,
        )

    async def _get_json(self, url: str, *, discovery: bool = False) -> dict[str, Any]:
        if _origin(url) not in self.allowed_origins:
            raise ResourceTrustError("URL origin is outside browser policy")
        if self._fetch_document is not None:
            return deepcopy(dict(await self._fetch_document(url)))
        accept = (
            "application/agent-web-discovery+json, application/json"
            if discovery
            else f"{RESOURCE_MEDIA_TYPE}, application/json"
        )
        response = await request_json(
            url,
            headers={"Accept": accept},
            timeout=self.timeout,
            max_response_bytes=self.max_response_bytes,
            allow_private_networks=self.allow_private_networks,
        )
        if response.status != 200:
            raise ConnectionError(f"Agent Web endpoint returned HTTP {response.status}")
        return response.document


def _origin(url: str) -> str:
    parsed = urlsplit(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.fragment:
        raise ValueError("Agent Web browser URLs must be absolute HTTPS URLs")
    authority = parsed.hostname.lower()
    if parsed.port is not None and parsed.port != 443:
        authority = f"{authority}:{parsed.port}"
    return f"https://{authority}"
