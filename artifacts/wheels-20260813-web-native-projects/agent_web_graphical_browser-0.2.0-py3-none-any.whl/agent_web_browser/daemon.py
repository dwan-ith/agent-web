"""Loopback daemon: Web navigation, identity custody, and optional ANP calls."""

from __future__ import annotations

import asyncio
from copy import deepcopy
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from agent_web_server import PublisherIdentity, mount_identity
from anp.authentication.did_resolver import build_did_resolution_url
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from libagentweb import (
    ActionConfirmationRequired,
    AgentBrowser,
    RemoteANPError,
    ResourceTrustError,
    WebAgentBrowser,
)
from pydantic import BaseModel, ConfigDict, Field


class ConnectRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    agentDescriptionUrl: str = Field(min_length=1, max_length=2048)


class OpenRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    resourceUrl: str = Field(min_length=1, max_length=2048)


class OriginRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    origin: str = Field(min_length=1, max_length=512)


class ActionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    method: str = Field(pattern=r"^[A-Za-z][A-Za-z0-9_.-]{0,127}$")
    params: dict[str, Any] = Field(default_factory=dict)
    confirmed: bool = False
    resourceUrl: str | None = Field(default=None, max_length=2048)


class BrowserDaemon:
    """Single-user browser session; safe because the server binds loopback."""

    def __init__(
        self,
        *,
        identity: PublisherIdentity,
        did_document_path: str | Path,
        private_key_path: str | Path,
        allow_private_networks: bool = False,
    ) -> None:
        self.identity = identity
        self.did_document_path = str(did_document_path)
        self.private_key_path = str(private_key_path)
        self.allow_private_networks = allow_private_networks
        self.browser: AgentBrowser | WebAgentBrowser | None = None
        self.connected_agent: dict[str, str] | None = None
        self._lock = asyncio.Lock()

    def status(self) -> dict[str, Any]:
        return {
            "ready": True,
            "callerDid": self.identity.did,
            "connectedAgent": deepcopy(self.connected_agent),
            "allowedOrigins": (
                sorted(self.browser.allowed_origins) if self.browser else []
            ),
        }

    async def connect(self, agent_description_url: str) -> dict[str, Any]:
        async with self._lock:
            if agent_description_url.startswith("https://"):
                _https_url(agent_description_url)
                if urlsplit(agent_description_url).path == "/.well-known/agent-web":
                    web_candidate = WebAgentBrowser(
                        agent_description_url,
                        allow_private_networks=self.allow_private_networks,
                    )
                    description = await web_candidate.discover()
                    entry = await web_candidate.open_entrypoint()
                    self.browser = web_candidate
                    self.connected_agent = {
                        "name": str(entry.get("name", urlsplit(agent_description_url).hostname)),
                        "description": str(
                            entry.get("description", "Web-native Agent Web publisher")
                        ),
                        "url": agent_description_url,
                        "binding": "HTTP",
                    }
                    return {
                        "status": self.status(),
                        "entry": {"resource": entry, "verified": True},
                    }
                candidate = AgentBrowser(
                    agent_description_url,
                    did_document_path=self.did_document_path,
                    private_key_path=self.private_key_path,
                    allow_private_networks=self.allow_private_networks,
                )
            else:
                candidate = await AgentBrowser.from_handle_async(
                    agent_description_url,
                    did_document_path=self.did_document_path,
                    private_key_path=self.private_key_path,
                    allow_private_networks=self.allow_private_networks,
                )
            description = await candidate.discover_async()
            entry = await candidate.open_entrypoint_async()
            self.browser = candidate
            self.connected_agent = {
                "name": str(description["name"]),
                "description": str(description["description"]),
                "url": candidate.agent_description_url,
                "binding": "ANP",
            }
            if candidate.handle_binding is not None:
                self.connected_agent["handle"] = candidate.handle_binding.handle
                self.connected_agent["bindingGeneration"] = (
                    candidate.handle_binding.binding_generation
                )
            return {
                "status": self.status(),
                "entry": {"resource": entry, "verified": True},
            }

    async def open(self, resource_url: str) -> dict[str, Any]:
        browser = self._require_browser()
        if isinstance(browser, WebAgentBrowser):
            resource = await browser.open(resource_url)
        else:
            resource = await browser.open_async(resource_url)
        return {"resource": resource, "verified": True}

    def allow_origin(self, origin: str) -> dict[str, Any]:
        browser = self._require_browser()
        parsed = urlsplit(origin)
        if (
            parsed.scheme != "https"
            or not parsed.netloc
            or parsed.path not in {"", "/"}
            or parsed.query
            or parsed.fragment
            or parsed.username
            or parsed.password
        ):
            raise ValueError("origin must be an absolute HTTPS origin")
        normalized = f"https://{parsed.netloc}"
        browser.allowed_origins.add(normalized)
        return self.status()

    async def call(
        self,
        method: str,
        params: dict[str, Any],
        *,
        confirmed: bool,
        resource_url: str | None = None,
    ) -> dict[str, Any]:
        browser = self._require_browser()
        if isinstance(browser, WebAgentBrowser):
            raise ValueError(
                "this action has no implemented Web-native HTTP invocation binding"
            )
        resource = await browser.call_async(
            method,
            params,
            confirmed=confirmed,
            resource_url=resource_url,
        )
        return {"resource": resource, "verified": True}

    def _require_browser(self) -> AgentBrowser | WebAgentBrowser:
        if self.browser is None:
            raise ValueError("connect to Web discovery or an optional Agent Description first")
        return self.browser


def create_app(
    *,
    identity: PublisherIdentity,
    did_document_path: str | Path,
    private_key_path: str | Path,
    base_url: str,
    static_directory: str | Path | None = None,
    allow_private_networks: bool = False,
) -> FastAPI:
    """Create the local UI/API server; callers must bind it to loopback."""

    parsed = urlsplit(base_url)
    if parsed.scheme != "https" or parsed.hostname not in {"localhost", "127.0.0.1"}:
        raise ValueError("graphical browser must use an HTTPS loopback base URL")
    if urlsplit(build_did_resolution_url(identity.did)).netloc != parsed.netloc:
        raise ValueError("browser DID-WBA identity is not bound to base_url")
    daemon = BrowserDaemon(
        identity=identity,
        did_document_path=did_document_path,
        private_key_path=private_key_path,
        allow_private_networks=allow_private_networks,
    )
    app = FastAPI(
        title="Agent Web Browser daemon",
        version="0.2.0",
        docs_url=None,
        redoc_url=None,
    )
    mount_identity(
        app,
        identity,
        agent_description_url=f"{base_url.rstrip('/')}/browser/ad.json",
    )

    @app.middleware("http")
    async def local_boundary(request: Request, call_next: Any) -> Any:
        expected = parsed.netloc.lower()
        if request.headers.get("host", "").lower() != expected:
            return JSONResponse(
                status_code=421,
                content={"detail": "unexpected loopback authority"},
            )
        if request.url.scheme != "https":
            return JSONResponse(
                status_code=400,
                content={"detail": "HTTPS is required"},
            )
        origin = request.headers.get("origin")
        if request.method not in {"GET", "HEAD"} and origin:
            if origin.rstrip("/") != base_url.rstrip("/"):
                return JSONResponse(
                    status_code=403,
                    content={"detail": "cross-origin mutation blocked"},
                )
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Permissions-Policy"] = (
            "camera=(), microphone=(), geolocation=()"
        )
        response.headers["Cross-Origin-Resource-Policy"] = "same-origin"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; "
            "img-src 'self'; connect-src 'self'; base-uri 'none'; "
            "frame-ancestors 'none'; form-action 'self'"
        )
        if request.url.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        return response

    @app.get("/browser/ad.json")
    async def browser_description() -> dict[str, Any]:
        return identity.sign_document(
            {
                "protocolType": "ANP",
                "protocolVersion": "1.1",
                "type": "AgentApplication",
                "url": f"{base_url.rstrip('/')}/browser/ad.json",
                "identifier": identity.did,
                "name": "Agent Web Browser",
                "description": "Local identity-holding Agent Web user agent.",
                "interfaces": [],
            }
        )

    @app.get("/api/status")
    async def status() -> dict[str, Any]:
        return daemon.status()

    @app.post("/api/connect")
    async def connect(body: ConnectRequest) -> dict[str, Any]:
        return await _safe(daemon.connect(body.agentDescriptionUrl))

    @app.post("/api/open")
    async def open_resource(body: OpenRequest) -> dict[str, Any]:
        return await _safe(daemon.open(body.resourceUrl))

    @app.post("/api/origins")
    async def allow_origin(body: OriginRequest) -> dict[str, Any]:
        try:
            return daemon.allow_origin(body.origin)
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc

    @app.post("/api/actions")
    async def action(body: ActionRequest) -> dict[str, Any]:
        return await _safe(
            daemon.call(
                body.method,
                body.params,
                confirmed=body.confirmed,
                resource_url=body.resourceUrl,
            )
        )

    assets = Path(static_directory) if static_directory else _default_static_dir()
    if assets.is_dir() and (assets / "index.html").is_file():
        app.mount("/", StaticFiles(directory=assets, html=True), name="ui")
    else:
        @app.get("/")
        async def missing_ui() -> FileResponse:
            raise HTTPException(
                503,
                "graphical assets are not built; run the browser UI build",
            )

    app.state.browser_daemon = daemon
    return app


async def _safe(awaitable: Any) -> dict[str, Any]:
    try:
        return await awaitable
    except ActionConfirmationRequired as exc:
        raise HTTPException(409, str(exc)) from exc
    except PermissionError as exc:
        raise HTTPException(403, str(exc)) from exc
    except (ConnectionError, RemoteANPError, ResourceTrustError, ValueError) as exc:
        raise HTTPException(400, str(exc)) from exc


def _https_url(value: str) -> None:
    parsed = urlsplit(value)
    if parsed.scheme != "https" or not parsed.netloc:
        raise ValueError("discovery URL must use absolute HTTPS")


def _default_static_dir() -> Path:
    return Path(__file__).resolve().parent / "static"
